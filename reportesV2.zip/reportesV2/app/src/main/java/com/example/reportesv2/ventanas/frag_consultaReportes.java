package com.example.reportesv2.ventanas;

import android.app.Activity;

public class frag_consultaReportes extends Activity {
}
